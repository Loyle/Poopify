<?php
$bdd = new PDO('mysql:host=localhost;dbname=Poopify', 'Poopify', '*20SecretPoop20*');

$bdd -> exec("set names utf8");
?>